

public class MenuS {


    private String me;



    public void menuu(){

        System.out.println("       MENU    ");
        System.out.println("1.CRIAR NOVA LISTA");
        System.out.println("2.ACESSAR LISTAS");
        System.out.println("3.SAIR");

    }

    public void Codigo(int cod){

    }
}
