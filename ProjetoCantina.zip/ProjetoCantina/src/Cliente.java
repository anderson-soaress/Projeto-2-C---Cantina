


public class Cliente {


   //refazer essa parte,
    private String nome;
    private String pedido;
    private int cod;


    public String getNome() {
        return nome;
    }






    public String cc(){
        System.out.println("NOME CLIENTE: ");

        return nome;
    }
    public String pp(){
        System.out.println("PEDIDO: ");

        return pedido;
    }

    public int codig(){
        System.out.println("CODIGO DO PEDIDO: ");
        return cod;
    }




}
